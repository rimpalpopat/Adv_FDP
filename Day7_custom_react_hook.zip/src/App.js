import './App.css';
//import UserEffectDemo from './Components/useEffect'
import CustomHookDemoComponent_1 from './Components/CustomHookDemoComponent_1';
import CustomHookDemoComponent_2 from './Components/CustomHookDemoComponent_2';

function App() {
  return (
    //<UserEffectDemo/>
    <> 
        <CustomHookDemoComponent_1 />
        <CustomHookDemoComponent_2 />
    </> 
  );
}

export default App;
